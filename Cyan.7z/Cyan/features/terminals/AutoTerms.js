import { S2DPacketOpenWindow, sendWindowClick} from "../utils/utils"
import Terminal from "../utils/terminalUtils"
import Settings from "../../config"

let LastClickTime
let clickedWindow = false
let firstClick

register("step", () => {
  if (!Settings().AutoTerm) return;


    let delay = Settings().ClickDelay
    let fcDelay = Settings().FirstClickDelay
    let breakThreshold = Settings().BreakThreshold


    

    if (firstClick && (Date.now() - LastClickTime < fcDelay)) return;

    if (Date.now() - LastClickTime < delay) return;

    if (Date.now() - LastClickTime > breakThreshold) {
        clickedWindow = false
    }

    if (!Terminal.isInTerm() || clickedWindow) return;

    
    const Solution = Terminal.getSolution()
    
    if (!Solution || !Solution.length) return;

    const currentClick = Solution.shift()    
    

    sendWindowClick(currentClick[0], currentClick[1], currentClick[2], 0)
    LastClickTime = Date.now()
    clickedWindow = true
    firstClick = false

})

register("step", () => {
    if (!Terminal.isInTerm()) {
        firstClick = true
        LastClickTime = Date.now()
    }
})

register("packetReceived", () => {
    clickedWindow = false
}).setFilteredClass(S2DPacketOpenWindow)

const prefix = "&8[&3Cyan&8] ";
const termkey = new KeyBind("Cheater Features", Keyboard.KEY_NONE, ".CyanAddons")

register("step", () => {
    if (termkey.isPressed())
	{
		Settings().TerminalAura = !Settings().TerminalAura;
		Settings().AutoTerm = !Settings().AutoTerm;
		Settings().TerminalInvwalk = !Settings().TerminalInvwalk;
		ChatLib.chat(prefix + `terminal cheats ${Settings().TerminalInvwalk ? "&aEnabled" : "&cDisabled"}`);	
	}
})
