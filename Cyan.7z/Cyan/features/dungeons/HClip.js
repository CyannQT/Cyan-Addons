import { Prefix, KeyBinding } from "../utils/utils"; 


const keybinds = [
	Client.getMinecraft().field_71474_y.field_74351_w.func_151463_i(),
	Client.getMinecraft().field_71474_y.field_74370_x.func_151463_i(),
	Client.getMinecraft().field_71474_y.field_74366_z.func_151463_i(),
	Client.getMinecraft().field_71474_y.field_74368_y.func_151463_i()
];

const speedVal = () => {
    return ((4.317*1.3)/20) * (Player.getPlayer().field_71075_bZ.func_75094_b() * 10);
};

const stopMovement = () => {
    for (i = 0; i < keybinds.length; i++) KeyBinding.func_74510_a(keybinds[i], false);
    Player.getPlayer().func_70016_h(0, Player.getPlayer().field_70181_x, 0);
};

export const clip = (dist = 1.4030250000000002) => {
    ChatLib.chat(Prefix + "&aHClip Enabled");
    const rads = Player.getYaw() * Math.PI / 180;      
    // 1.4030250000000002
    const changeX = -Math.sin(rads) * dist;
    const changeZ = Math.cos(rads) * dist;
    stopMovement();
    Client.scheduleTask(0, () => {
        Player.getPlayer().func_70016_h(changeX, Player.getPlayer().field_70181_x, changeZ);
        for (i = 0; i < keybinds.length; i++) KeyBinding.func_74510_a(keybinds[i], Keyboard.isKeyDown(keybinds[i]));
    });
}

register("command", () => {
    clip()
}).setName("hclip")