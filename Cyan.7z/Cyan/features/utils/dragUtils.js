import { Prefix, S0FPacketSpawnMob, S2APacketParticle, S32PacketConfirmTransaction, enchantmentTableParticle, getClass, convertFixedPoint, getDistance3D } from "./utils";

const colors = {
    "orange": {x: [82, 88], y: [15, 22], z: [53, 59]},
    "red": {x: [24, 30], y: [15, 22], z: [56, 62]},
    "green": {x: [23, 29], y: [15, 22], z: [91, 97]}, 
    "purple": {x: [53, 59], y: [15, 22], z: [122, 128]},
    "blue": {x: [82, 88], y: [15, 22], z: [91, 97]},
};

const priorities = {
    "Archer": ["purple", "blue", "red", "green", "orange"],
    "Tank": ["purple", "blue", "red", "green", "orange"],
    "Mage": ["orange", "green", "red", "blue", "purple"],
    "Berserk": ["orange", "green", "red", "blue", "purple"],
    "Healer": ["orange", "green", "red", "blue", "purple"]
};

function isWithinRange(value, range) {
    return value >= range[0] && value <= range[1];
}

const prio = "pbrgo";

export default new class dragHelper { 
    constructor() {
        this.dragonInfo = {
            "orange": {spawning: false, tillSpawn: 0, spawnCoords: [85, 18, 56], dragEntity: null, spawned: false},
            "red": {spawning: false, tillSpawn: 0, spawnCoords: [27, 18, 59], dragEntity: null, spawned: false},
            "green": {spawning: false, tillSpawn: 0, spawnCoords: [26, 18, 94], dragEntity: null, spawned: false},
            "purple": {spawning: false, tillSpawn: 0, spawnCoords: [56, 18, 125], dragEntity: null, spawned: false},
            "blue": {spawning: false, tillSpawn: 0, spawnCoords: [85, 18, 94], dragEntity: null, spawned: false}
        };
        


        register("packetReceived", (packet, event) => {
            if (packet.func_179749_a() !== enchantmentTableParticle) return;

            const x = packet.func_149220_d() // x
            const y = packet.func_149226_e() // y
            const z = packet.func_149225_f() // z

            for (let color in colors) {
                let { x: xRange, y: yRange, z: zRange } = colors[color];
                if (
                    isWithinRange(x, xRange) &&
                    isWithinRange(y, yRange) &&
                    isWithinRange(z, zRange)
                ) {
                    if (!this.dragonInfo[color].spawning && !this.dragonInfo[color].spawned) {
                        this.dragonInfo[color].spawning = true;
                        this.dragonInfo[color].tillSpawn = 100;
                        this.dragonInfo[color].dragEntity = null
                        ChatLib.chat(Prefix + `&c${color} &adragon is spawning. tillSpawn set to 100.`);
                    }
                }
            }

        }).setFilteredClass(S2APacketParticle)

        register("packetReceived", (packet, event) => {
            for (let color in colors) {
                if (this.dragonInfo[color].spawning) {
                    this.dragonInfo[color].tillSpawn--;
                    if (this.dragonInfo[color].tillSpawn == 0) {
                        this.dragonInfo[color].spawning = false
                    }
                }
            }
        }).setFilteredClass(S32PacketConfirmTransaction);

        register("packetReceived", (packet, event) => {
            if (packet.func_149025_e() !== 63) return;
        
            const x = (convertFixedPoint(packet.func_149023_f()))
            const y = (convertFixedPoint(packet.func_149034_g()))
            const z = (convertFixedPoint(packet.func_149029_h()))
            const entityID = packet.func_149024_d()

            for (let color in colors) {
                let spawnCoords = this.dragonInfo[color].spawnCoords;
                if (!spawnCoords) return;
                let distance = getDistance3D(x, y, z, spawnCoords[0], spawnCoords[1], spawnCoords[2]);
                if (distance <= 15) {
                    Client.scheduleTask(2, () => {
                        let mcEntity = World.getWorld().func_73045_a(entityID)
                        let ctEntity = new Entity(mcEntity)
                        this.dragonInfo[color].dragEntity = ctEntity
                        this.dragonInfo[color].spawned = true
                        setTimeout(() => {
                            this.dragonInfo[color].spawned = false
                        }, 3000);
                    })
                    break
                }
            }

        
        }).setFilteredClass(S0FPacketSpawnMob)

        register("RenderOverlay", () => {
            return;
            const dragInfo = this.getDragInfo(this.getPrio())
            if (!dragInfo) return;

            const inTerminalText = "&3" + dragInfo.tillSpawn * 50
            const scale = 1.5;
            Renderer.scale(scale);
            Renderer.drawStringWithShadow(inTerminalText, (Renderer.screen.getWidth() / scale - Renderer.getStringWidth(inTerminalText)) / 2, Renderer.screen.getHeight() / scale / 2 + 10);
    
        })
    }
    
    _simDragon(dragon) {
        this.dragonInfo[dragon].spawning = true
        this.dragonInfo[dragon].tillSpawn = 100;
        this.dragonInfo[dragon].dragEntity = null
        ChatLib.chat(Prefix + `&c${dragon} &adragon is spawning. tillSpawn set to 100.`);
    }

    getDragInfo(dragon) {
        return this.dragonInfo[dragon] || null;
    }

    getPrio() {    
        const currentClass = "Archer"
        const priorityOrder = priorities[currentClass] || [];
    
        return priorityOrder.find(color => this.dragonInfo[color]?.spawning || this.dragonInfo[color]?.spawned) || null;
    }
    
}
