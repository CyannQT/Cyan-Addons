import petHelper from "./utils/petUtils"
import leapHelper from "./utils/leapUtils"
import Terminal from "./utils/terminalUtils"
import serverRotations from "./utils/serverRotations"
import Pathfinder from "./utils/pathUtils"
import dragHelper from "./utils/dragUtils"
import { C05PacketPlayerLook, MouseEvent, S0FPacketSpawnMob, S2FPacketSetSlot, calcYawPitch, snapTo } from "./utils/utils"
import pathUtils from "./utils/pathUtils"
import Settings from "../config"

let shouldLook = false
let targetx
let targety
let targetz
let ctEntity


register("command", (x,y,z) => {   
    targetx = parseInt(x)
    targety = parseInt(y)
    targetz = parseInt(z)
}).setName("lookat")

register("command", () => {
    console.log(Settings().AutoTerm)
}).setName("start")

// { x: 24, y: 5, z: 56, shouldJump: true, shouldSnap: false, yawPitch: [0, 0], ignoreY: true },
// { x: 22, y: 5, z: 58, shouldJump: false, shouldSnap: true, yawPitch: [39.5, 14.7], ignoreY: true}

register("tick", () => {
    if (!shouldLook) return;
    if (!ctEntity) return;
    const vec = ctEntity.getEyePosition(Tessellator.getPartialTicks())
    const [yaw, pitch] = calcYawPitch({x:vec.field_72450_a,y:vec.field_72448_b -4, z:vec.field_72449_c})
    snapTo(yaw, pitch)
})


function convertFixedPoint(fixedValue, n = 5) {
    return fixedValue / (1 << n)
}

register("packetReceived", (packet, event) => {
    if (packet.func_149025_e() !== 63) return;

    console.log(convertFixedPoint(packet.func_149023_f()))
    console.log(convertFixedPoint(packet.func_149034_g()))
    console.log(convertFixedPoint(packet.func_149029_h()))
    const entityID = packet.func_149024_d()

    Client.scheduleTask(1, () => {
        const mcEntity = World.getWorld().func_73045_a(entityID)
        ctEntity = new Entity(mcEntity)
    })

}).setFilteredClass(S0FPacketSpawnMob)


//archer
// Pathfinder.addPath(24, 5, 56, true, false, [30, 30]);
// Pathfinder.addPath(22, 5, 58, false, true, [39.5, 14.7]);

// berserk
// Pathfinder.addPath(86, 5, 52, true, false, [30, 30]);
// Pathfinder.addPath(91, 5, 56, false, true, [-66.2, 15.6]);

//Orange stackfrom: 49, 4, 88, lookat:85, 24, 55.5
//Blue stackfrom: 36, 5, 113 lookat:85, 23, 96.5
//Red stackfrom: 33, 4, 94 lookat: 27.5, 22, 59
//Green stackfrom: 67, 4, 70 lookat: 20, 24, 93
//Purple stackfrom: 22, 5, 94 lookat: 56, 22, 125