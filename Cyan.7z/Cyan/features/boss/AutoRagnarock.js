import { getClass, getItemSlot, rightClick } from "../utils/utils"
import petHelper from "../utils/petUtils"
import Settings from "../../config"
let equipDrag

register("chat", () => {
    if (!Settings().AutoRag) return;
    const currentClass = getClass()
    if (currentClass !== "Archer" && currentClass !== "Berserk" && currentClass !== "Mage") return;

    let ragSlot = getItemSlot("Ragnarock")

    
    if (ragSlot > 8 || ragSlot < 0) return;
    
    Player.setHeldItemIndex(ragSlot)

    setTimeout(() => {
        rightClick()
    }, 50);

    petHelper.queuePet("golden", "remedies")
    equipDrag = true

}).setCriteria("[BOSS] Wither King: I no longer wish to fight, but I know that will not stop you.")


register("actionBar", (message) => {
    if (!equipDrag) return;
    equipDrag = false

    petHelper.queuePet("ender", "plushie")
}).setChatCriteria(/.*\bCASTING\b$/);   