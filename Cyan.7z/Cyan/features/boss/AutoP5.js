import dragHelper from "../utils/dragUtils"
import Pathfinder from "../utils/pathUtils"
import serverRotations from "../utils/serverRotations"
import { calcYawPitch, getItemSlot, rightClick, useItem, getClass } from "../utils/utils"

let currentClass
let startScanning = false
let lastDragon

let pathToStack
let startStacking
let currentDragon
let currentPath
let shouldShoot
let rotationsReset

register("chat", () => {
    currentClass = getClass()
    if (currentClass !== "Berserk" && currentClass !== "Archer") return;
    startScanning = true

}).setCriteria("[BOSS] Wither King: I no longer wish to fight, but I know that will not stop you.")

register("worldUnload", () => {
    startScanning = false
})

const stackSpots = [
    {
        dragon: "orange",
        startStack: { x: 49, y: 4, z: 88, shouldJump: true, shouldSnap: false, yawPitch: [0, 0], ignoreY: true },
        stackTo: { x: 78, y: 4, z: 61, shouldJump: false, shouldSnap: false, yawPitch: [0, 0], ignoreY: true },
        lookAt: { x: 85, y: 24, z: 55.5 }
    },
    {
        dragon: "blue",
        startStack: { x: 31, y: 5, z: 109, shouldJump: true, shouldSnap: false, yawPitch: [0, 0], ignoreY: true },
        stackTo: { x: 81, y: 5, z: 97, shouldJump: false, shouldSnap: false, yawPitch: [0, 0], ignoreY: true },
        lookAt: { x: 85, y: 23, z: 96.5 }
    },
    {
        dragon: "red",
        startStack: { x: 33, y: 4, z: 94, shouldJump: false, shouldSnap: false, yawPitch: [0, 0], ignoreY: true },
        stackTo: { x: 28, y: 4, z: 64, shouldJump: false, shouldSnap: false, yawPitch: [0, 0], ignoreY: true },
        lookAt: { x: 27.5, y: 22, z: 59 }
    },
    {
        dragon: "green",
        startStack: { x: 67, y: 4, z: 70, shouldJump: true, shouldSnap: false, yawPitch: [0, 0], ignoreY: true },
        stackTo: { x: 34, y: 4, z: 86, shouldJump: false, shouldSnap: false, yawPitch: [0, 0], ignoreY: true },
        lookAt: { x: 20, y: 24, z: 93 }
    },
    {
        dragon: "purple",
        startStack: { x: 24, y: 4, z: 90, shouldJump: true, shouldSnap: false, yawPitch: [0, 0], ignoreY: true },
        stackTo: { x: 42, y: 5, z: 111, shouldJump: false, shouldSnap: false, yawPitch: [0, 0], ignoreY: true },
        lookAt: { x: 56, y: 22, z: 125 }
    }
];


//Orange stackfrom: 49, 4, 88, lookat:85, 24, 55.5
//Blue stackfrom: 36, 5, 113 lookat:85, 23, 96.5
//Red stackfrom: 33, 4, 94 lookat: 27.5, 22, 59
//Green stackfrom: 67, 4, 70 lookat: 20, 24, 93
//Purple stackfrom: 22, 5, 94 lookat: 56, 22, 125






register("tick", () => {
    if (!startScanning) return;

    currentDragon = dragHelper.getPrio()
    if (!currentDragon) {
        setTimeout(() => {
            
        pathToStack = false
        startStacking = false
        shouldShoot = false
        if (!rotationsReset) {
            Client.scheduleTask(60, () => {
            serverRotations.resetRotation()
            useItem.setState(false)
            rotationsReset = true
            })
        }
        return;
    }, 3000);
    }

    currentPath = stackSpots.find(stack => stack.dragon === currentDragon);
    if (!currentPath) return;
    if (!pathToStack) {
        pathToStack = true
        Pathfinder.addPath(
        currentPath.startStack.x,
        currentPath.startStack.y,
        currentPath.startStack.z,
        currentPath.startStack.shouldJump,
        currentPath.startStack.shouldSnap,
        currentPath.startStack.yawPitch,
        currentPath.startStack.ignoreY)
    }

    const dragInfo = dragHelper.getDragInfo(currentDragon)
    if (!dragInfo) return;

    if (!shouldShoot && (dragInfo.tillSpawn < 22)) {
        shouldShoot = true
    }

    if (!startStacking && (dragInfo.tillSpawn < 16)) {
        startStacking = true
        Pathfinder.addPath(
            currentPath.stackTo.x,
            currentPath.stackTo.y,
            currentPath.stackTo.z,
            currentPath.stackTo.shouldJump,
            currentPath.stackTo.shouldSnap,
            currentPath.stackTo.yawPitch,
            currentPath.stackTo.ignoreY)
    }

})

register("tick", () => {
    if (!shouldShoot) return;

    const termslot = getItemSlot("terminator")
    if (termslot !== Player.getHeldItemIndex()) {
        Player.setHeldItemIndex(termslot)
    }

    const dragInfo = dragHelper.getDragInfo(dragHelper.getPrio())
    if (!dragInfo) return;
    let targetX
    let targetY
    let targetZ
    if (dragInfo.dragEntity) {
        targetX = dragInfo.dragEntity.getX()
        targetY = dragInfo.dragEntity.getY() + 5
        targetZ = dragInfo.dragEntity.getZ()
    } else {
        currentPath = stackSpots.find(stack => stack.dragon === currentDragon);
        targetX = currentPath.lookAt.x
        targetY = currentPath.lookAt.y
        targetZ = currentPath.lookAt.z
    }


    const [yaw, pitch] = calcYawPitch({x:targetX, y:targetY, z:targetZ})

    useItem.setState(true)
    serverRotations.setRotation(yaw, pitch)
    rotationsReset = false

})


register("command", (arg) => {
    dragHelper._simDragon("purple")
    dragHelper._simDragon(arg)
}).setName("simdrag")